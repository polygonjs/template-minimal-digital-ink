import{a}from"./chunk-WSI7H36X.js";import"./chunk-VDLWCXQU.js";export{a as loadSceneAsync_lavalamp_01};
