import{a}from"./chunk-WSI7H36X.js";import"./chunk-VDLWCXQU.js";var c=async function(e={}){return e&&e.createViewer==null&&(e.createViewer=!0),a(e)};export{c as loadSceneAndMountAsync_lavalamp_01};
